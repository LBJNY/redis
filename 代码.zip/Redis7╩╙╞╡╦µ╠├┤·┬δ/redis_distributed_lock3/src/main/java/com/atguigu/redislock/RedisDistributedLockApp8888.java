package com.atguigu.redislock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @auther zzyy
 * @create 2023-01-04 15:57
 */
@SpringBootApplication
public class RedisDistributedLockApp8888
{
    public static void main(String[] args)
    {
        SpringApplication.run(RedisDistributedLockApp8888.class,args);
    }
}
