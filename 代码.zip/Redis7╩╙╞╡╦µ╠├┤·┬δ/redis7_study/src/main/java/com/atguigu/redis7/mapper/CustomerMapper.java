package com.atguigu.redis7.mapper;

import com.atguigu.redis7.entities.Customer;
import tk.mybatis.mapper.common.Mapper;

public interface CustomerMapper extends Mapper<Customer> {
}

