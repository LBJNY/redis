package com.atguigu.canal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @auther zzyy
 * @create 2022-12-23 11:59
 */
@SpringBootApplication
public class CanalDemo02App
{
    public static void main(String[] args)
    {
        //SpringApplication.run(CanalDemo02App.class,args);
    }
}
